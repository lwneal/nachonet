/*******************************************************************************
File:				hashTest.cpp
Author: 		Josh Siva
Date:				4/16/14
Project:		NachoNet
Purpose:		Collects data on the effectiveness of the jpw hash algorithm when
						used with MAC addresses as the keys and a variable (but small)
						number of buckets.
*******************************************************************************/

int main ()
{

	return 0;
}


