/*******************************************************************************
File:				DataFeeder.cpp
Author: 		Josh Siva
Date:				4/1/14
Project:		NachoNet
Purpose:		Implements the DataFeeder which mimics a data collection module with
						dummy data from a file. Data file is formatted like this:
						[number of devices]
						deviceID1 ss
						deviceID2 ss
						.
						.
						.

						There must be exactly five measurements for each device. Once the
						last of the five measurements is read in for each device it is saved
						off and read from for the remainder of the life of the program
*******************************************************************************/

#include "../../include/collect/DataFeeder.h"

/******************************************************************************
 * Constructor:	DataFeeder
 *
 * Description:	Opens up the file, reads in the number of devices, and
 * 							initializes the debug variable.
 *
 * Parameters: 	fileName - the name of the data file
 * 							debug - flag for whether we are in debug mode or not
 *
 * Returned:		None
 *****************************************************************************/
DataFeeder::DataFeeder (std::string fileName, bool debug) : dataCollect (debug)
{
	dataFile.open (fileName.c_str ());

	if (dataFile.good ())
	{
		dataFile >> numDevices;
	}
	else
	{
		numDevices = 0;
	}
}

/******************************************************************************
 * Destroyer!:	~DataFeeder
 *
 * Description:	Closes the file if it was successfully opened
 *
 * Parameters:	None
 *
 * Returned:		None
 *****************************************************************************/
DataFeeder::~DataFeeder ()
{
	if (dataFile.good ())
	{
		dataFile.close ();
	}
}

/******************************************************************************
 * Method:			readFromNetwork
 *
 * Description:	Pretends to read from the network by grabbing data from the
 * 							data file. Once five measurements for each device have been
 * 							read from the file, the fifth measurements for each device are
 * 							saved in a vector and are read from for the remainder of the
 * 							program.
 *
 * Parameters:	None
 *
 * Returned:		None
 *****************************************************************************/
void DataFeeder::readFromNetwork ()
{
	static int timesRead = 0;
	ssMeasurement ss;

	if (dataFile.good ())
	{
		if (CONTAINER_SIZE > timesRead)
		{
			//read from file
			for (int i = 0; i < numDevices; i++)
			{
				dataFile >> ss.devID >> ss.ss;
				update (ss.devID, ss.ss);

				if (CONTAINER_SIZE - 1 == timesRead)
				{
					//put into vector
					data.push_back (ss);
				}
			}

			timesRead++;
		}
		else
		{
			//read from vector
			for (ssMeasurement & entry : data)
			{
				update (entry.devID, entry.ss);
			}
		}
	}
}


