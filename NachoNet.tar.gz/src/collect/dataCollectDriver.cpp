/*******************************************************************************
File:				dataCollectDriver
Author: 		Josh Siva
Date:				1/27/14
Project:		NachoNet
Purpose:		Tests the functionality of the data collection modules
*******************************************************************************/

#include "../../include/collect/stdCollect.h"


int main ()
{
	stdCollect theCollector ("wlan0", false);

	theCollector.readFromNetwork();

	return 0;
}
