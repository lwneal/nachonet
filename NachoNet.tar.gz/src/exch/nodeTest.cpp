/*******************************************************************************
File:				nodeTest.cpp
Author: 		Josh Siva
Date:				4/16/14
Project:		NachoNet
Purpose:		Tests the node interactions with CouchDB
*******************************************************************************/

#include "../../exch/dataExOnTheCouch.h"

int main ()
{
	dataEx * pDataEx;
	location loc;
	node myNode;
	std::string id;
	std::vector<location> devLocations;
	char ch;

	srand (time (0));

	//add a device
	//wait to check other DBs for change

	pDataEx = new dataExOnTheCouch;



	delete pDataEx;

	return 0;
}


