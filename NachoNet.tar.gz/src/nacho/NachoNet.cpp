/*******************************************************************************
File:				NachoNet.cpp
Author: 		Josh Siva
Date:				3/19/14
Project:		NachoNet
Purpose:		Implements the behavior of the NachoNet object which is the object
						that integrates all of the pieces of NachoNet (including admin
						functionality)
*******************************************************************************/

#include "../../include/nacho/NachoNet.h"

const std::string NachoNet::DIST_CONFIG_FILE = "dist.conf";

/*******************************************************************************
 * Constructor:	NachoNet
 *
 * Description:	Initializes the debug and verbose variables. Sets up the
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
NachoNet::NachoNet (bool debug, bool verbose)
{
	Config distConfig (DIST_CONFIG_FILE);
	this->debug = debug;
	this->verbose = verbose;

	if (isVerbose ())
	{
		std::cout << "Initializing modules\n";
	}

	pDataCollect = new stdCollect (stdCollect::DEFAULT_IFACE, debug);
	pDistMeasure = new pathLoss (debug, &distConfig);
	pDataEx = NULL;
	pLocalization = new localization (debug);
	pWorker = NULL;

	active = true;
	pListener = new std::thread (&NachoNet::listener, this);

	if (isVerbose ())
	{
		std::cout << "Message listener started\n";
	}
}

/*******************************************************************************
 * Destroyer!:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
NachoNet::~NachoNet ()
{

	if (isVerbose ())
	{
		std::cout << "Deleting modules\n";
	}

	delete pDataCollect;
	delete pDistMeasure;

	if (NULL != pDataEx)
	{
		delete pDataEx;
	}

	delete pLocalization;

	if (NULL != pWorker)
	{
		if (isVerbose ())
		{
			std::cout << "Stopping NachoNet\n";
		}

		pDataEx->setIsAlive (false);

		pWorker->join ();
		delete pWorker;

		pWorker = NULL;
	}

	if (isVerbose ())
	{
		std::cout << "Stopping message listener\n";
	}

	active = false;
	pListener->join ();
	delete pListener;

	if (isVerbose ())
	{
		std::cout << "Adios!\n";
	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::stop ()
{
	Message message;

	if (!pDataEx->alive ())
	{
		std::cout << "NachoNet is already stopped... Now doing less than nothing.\n";
	}
	else if (NULL == pDataEx)
	{
		std::cout << "This node has not yet been added to NachoNet.\n";
	}
	else
	{
		pDataEx->setIsAlive (false);

		pWorker->join ();
		delete pWorker;

		pWorker = NULL;

		message.msg = dataEx::STOP;

		for (int id : pDataEx->getNodeIDs ())
		{
			message.dest.push_back (id);
		}

		pDataEx->ping (message);

		if (isVerbose ())
		{
			std::cout << "No more nachos :'(\n";
		}
	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::start ()
{
	Message message;
	if (pDataEx->alive ())
	{
		std::cout << "NachoNet is already running\n";
	}
	else if (NULL == pDataEx)
	{
		std::cout << "This node has not yet been added to NachoNet.\n";
	}
	else
	{
		pDataEx->setIsAlive (true);

		pWorker = new std::thread (&NachoNet::worker, this);

		message.msg = dataEx::START;

		for (int id : pDataEx->getNodeIDs ())
		{
			message.dest.push_back (id);
		}

		pDataEx->ping (message);

		if (isVerbose ())
		{
			std::cout << "Nachos for everyone! :D\n";
		}
	}

}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::worker ()
{
	while (pDataEx->alive ())
	{
		//do stuff

	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::listener ()
{
	bool stateChange = false;

	while (active)
	{
		if (NULL != pDataEx)
		{
			pDataEx->checkMessages ();

			stateChange = stateChange ^ pDataEx->alive ();

			if (stateChange && pDataEx->alive ())
			{
				pDataEx->setIsAlive (true);

				pWorker = new std::thread (&NachoNet::worker, this);
			}
			else if (stateChange && !pDataEx->alive ())
			{
				stateChange = false;

				pWorker->join ();
				delete pWorker;

				pWorker = NULL;

			}
		}
	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::listDevices ()
{
	//print a nice table
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::addNode ()
{
	if (NULL != pDataEx)
	{
		std::cout << "This node has already been added.\n";
	}
	else
	{
		if (isVerbose ())
		{
			std::cout << "Adding node to NachoNet...\n";
		}

		pDataEx = new dataExOnTheCouch ();


		if (isVerbose ())
		{
			std::cout << "Node added! Be sure to update the node's location under the "
								<< "management menu.\n";
		}
	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:		None
 ******************************************************************************/
void NachoNet::dropNode ()
{
	if (NULL == pDataEx)
	{
		std::cout << "This node has not been added.\n";
	}
	else
	{
		if (isVerbose ())
		{
			std::cout << "Removing node from NachoNet...\n";
		}

		delete pDataEx;
		pDataEx = NULL;


		if (isVerbose ())
		{
			std::cout << "Node removed.\n";
		}
	}
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:
 ******************************************************************************/
bool NachoNet::isDebug ()
{
	return this->debug;
}

/*******************************************************************************
 * Method:
 *
 * Description:
 *
 * Parameters:	None
 *
 * Returned:
 ******************************************************************************/
bool NachoNet::isVerbose ()
{
	return this->verbose;
}


