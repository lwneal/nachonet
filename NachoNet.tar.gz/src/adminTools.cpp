/*******************************************************************************
File:				adminTools.cpp
Author: 		Josh Siva
Date:				10/21/13
Project:		NachoNet
Purpose:		Provides the structure for testing modules, managing nodes, and
						managing NachoNet
*******************************************************************************/

#include "../include/adminTools.h"
#include <string.h>
#include <iostream>

int main()
{
	char selection;

	std::cout << "Main Menu\n";
	std::cout << "---------\n\n";

	std::cout << "0. Test\n";
	std::cout << "1. Node Management\n";
	std::cout << "2. Start\n";
	std::cout << "3. Stop\n";
	std::cout << "4. List Devices\n\n";

	std::cout << "Enter Selection: ";
	std::cin >> selection;


	return 0;
}
