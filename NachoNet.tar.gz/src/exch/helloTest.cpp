/*******************************************************************************
File:				helloTest.cpp
Author: 		Josh Siva
Date:				4/16/14
Project:		NachoNet
Purpose:		Tests the hello system of data exchange
*******************************************************************************/

#include "../../include/exch/dataExOnTheCouch.h"

int main ()
{

	return 0;
}


