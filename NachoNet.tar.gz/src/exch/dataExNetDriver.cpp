/*******************************************************************************
File:				dataExNetDriver.cpp
Author: 		Josh Siva
Date:				4/8/14
Project:		NachoNet
Purpose:		Tests the networking aspects of the data exchange module
*******************************************************************************/
#include "../../include/exch/dataExOnTheCouch.h"
#include <iostream>

int main ()
{
	char ch;
	dataEx *pDataEx = NULL;

	//test entry into NachoNet
	std::cout << "enter a char then hit enter to begin: ";
	std::cin >> ch;

	pDataEx = new dataExOnTheCouch;

	std::cout << "I have " << pDataEx->getNumNodes () << " nodes "
						<< "and " << pDataEx->getNumDevs () << " devices\n";

	//test exit of NachoNet
	std::cout << "enter a char then hit enter to begin: ";
	std::cin >> ch;

	pDataEx->checkMessages ();


	delete pDataEx;

	return 0;
}
